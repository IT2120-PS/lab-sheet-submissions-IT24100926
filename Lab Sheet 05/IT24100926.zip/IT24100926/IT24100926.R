setwd("C:\\Users\\IT24100926\\Desktop\\IT24100926")
Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE,sep=" ")
fix(Delivery_Times)
names(Delivery_Times)<-c("X1")
attach(Delivery_Times)
histogram<-hist(X1,main = "Delivery Times Histogram",seq(20,70,length= 10),right=TRUE)

#The histogram shows that delivery times are roughly symmetric and bell-shaped, with most values around 40–45 minutes.
#This suggests the data is approximately normally distributed.

histogram
freq<-histogram$counts
freq
mid<-histogram$mids
mid
plot(mid,freq,type = 'l',main = " Cumulative frequency polygon",ylim = c(0,max(freq)))
